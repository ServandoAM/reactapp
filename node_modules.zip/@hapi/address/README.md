# address

Validate email address and domain

Lead Maintainer: [Eran Hammer](https://github.com/hueniverse)

[![Build Status](https://secure.travis-ci.org/hapijs/address.svg)](http://travis-ci.org/hapijs/address)
