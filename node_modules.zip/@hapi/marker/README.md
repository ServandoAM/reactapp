<a href="http://hapijs.com"><img src="https://raw.githubusercontent.com/hapijs/assets/master/images/family.png" width="180px" align="right" /></a>

# marker

Cross modules and cross versions shared symbols.

[![Build Status](https://travis-ci.org/hapijs/marker.svg?branch=master)](https://travis-ci.org/hapijs/marker)

