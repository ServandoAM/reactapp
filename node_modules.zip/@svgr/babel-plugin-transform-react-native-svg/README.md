# @svgr/babel-plugin-transform-react-native-svg

## Install

```
npm install --save-dev @svgr/babel-plugin-transform-react-native-svg
```

## Usage

**.babelrc**

```json
{
  "plugins": ["@svgr/babel-plugin-transform-react-native-svg"]
}
```

## License

MIT
