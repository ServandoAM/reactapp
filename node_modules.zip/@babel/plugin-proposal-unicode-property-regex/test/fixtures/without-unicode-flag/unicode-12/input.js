var regex = /\p{Script_Extensions=Wancho}/u;
