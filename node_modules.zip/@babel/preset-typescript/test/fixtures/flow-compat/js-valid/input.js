type Foo = {||};

foo;
